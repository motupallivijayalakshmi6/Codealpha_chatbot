import streamlit as st
from openai import OpenAI

# ------------------ PAGE CONFIG ------------------
st.set_page_config(
    page_title="Groq AI Chatbot",
    page_icon="🤖",
    layout="wide"
)

# ------------------ GROQ CLIENT ------------------
client = OpenAI(
    api_key="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",
    base_url="https://api.groq.com/openai/v1"
)

# ------------------ CSS ------------------
st.markdown("""
<style>

/* Main App */
.stApp{
    background:#121212!important;
    color:white !important;
}

/* Main Container */
.main .block-container{
    background:#121212!important;
    color:white !important;
    padding-top:20px;
    max-width:1000px;
}

/* Streamlit Header */
header{
    background:#0b1120 !important;
}

/* Toolbar */
[data-testid="stHeader"]{
    background:#0b1120 !important;
}

/* Main Content */
[data-testid="stAppViewContainer"]{
    background:#121212 !important;
}

/* Sidebar */
[data-testid="stSidebar"]{
    background:#121212 !important;
}

[data-testid="stSidebar"] *{
    color:white !important;
}

/* Chat Bubble */
[data-testid="stChatMessage"]{
    background:#2b2b2b !important;
    border-radius:15px;
    padding:12px;
    margin-bottom:10px;
}

/* Chat Text */
[data-testid="stChatMessageContent"],
[data-testid="stChatMessageContent"] *{
    color:white !important;
}

/* Chat Input */
[data-testid="stChatInput"]{
    position:fixed;
    bottom:20px;
    left:50%;
    transform:translateX(-50%);
    width:65%;
    max-width:800px;
    z-index:999;
}
[data-testid="stChatInput"] textarea{
    padding-left:15px !important;
    font-size:16px !important;
}
[data-testid="stChatInput"] textarea{
    background:#1e293b !important;
    color:white !important;
    border-radius:10px;
}

[data-testid="stChatInput"] textarea::placeholder{
    color:#cbd5e1 !important;
}

/* Buttons */
.stButton>button{
    background:#dc2626 !important;
    color:white !important;
    border:none;
    border-radius:10px;
    height:50px;
    font-weight:bold;
}

/* Titles */
h1,h2,h3,p,span,label{
    color:white !important;
}
textarea::placeholder{
    color:#bdbdbd !important;
    opacity:1 !important;
}

/* Remove top blue strip */
header[data-testid="stHeader"]{
    background: transparent !important;
    height: 0rem !important;
}

[data-testid="stToolbar"]{
    display: none !important;
}

[data-testid="stDecoration"]{
    display: none !important;
}

[data-testid="stStatusWidget"]{
    display: none !important;
}

[data-testid="stHeader"]{
    background: transparent !important;
    box-shadow: none !important;
}

</style>
""", unsafe_allow_html=True)

# ------------------ SIDEBAR ------------------
with st.sidebar:
    st.title("⚙️ Settings")

    if st.button("🗑 Clear Chat",
    use_container_width=True):
        st.session_state.messages = []
        st.rerun()


# ------------------ TITLE ------------------
st.markdown("""
<h1 style="
text-align:center;
color:white;
font-size:45px;
margin-bottom:20px;
">
🤖 Groq AI Chatbot
</h1>
""", unsafe_allow_html=True)


# ------------------ CHAT HISTORY ------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# ------------------ CHAT INPUT ------------------
prompt = st.chat_input("Ask anything...")

if prompt:

    st.session_state.messages.append(
        {"role":"user","content":prompt}
    )

    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):

        with st.spinner("Thinking... 🤔"):

            try:

                response = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=st.session_state.messages
                )

                reply = response.choices[0].message.content

                st.markdown(reply)

                st.session_state.messages.append(
                    {
                        "role":"assistant",
                        "content":reply
                    }
                )

            except Exception as e:
                st.error(e)